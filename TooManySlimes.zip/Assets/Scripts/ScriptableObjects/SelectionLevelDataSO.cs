using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Stage  -  SelectionLevelDataSO", menuName = "LevelDataSO/New Selection Level Data")]
public class SelectionLevelDataSO : LevelDataSO
{
    public ItemRairity rairity;
}