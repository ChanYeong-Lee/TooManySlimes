using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Stage  -  CoinLevelData", menuName = "LevelDataSO/New Coin Level Data")]
public class CoinLevelDataSO : LevelDataSO
{
    public int coinAmount;
}
