using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Stage  -  BossLevelDataSO", menuName = "LevelDataSO/New Boss Level Data")]
public class BossLevelDataSO : LevelDataSO
{
    public GameObject bossPrefab;
}