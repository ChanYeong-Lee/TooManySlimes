using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Stage  -  ShopLevelDataSO", menuName = "LevelDataSO/New Shop Level Data")]
public class ShopLevelDataSO : LevelDataSO
{ }