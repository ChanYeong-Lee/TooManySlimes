using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LevelData
{
    public LevelDataSO levelDataSO;
    public float startHeight;
}
